package com.pages;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class DashboardPageTest {

    WebDriver driver;

    By appName = By.id("appName");
    By pageTitle = By.id("pageTitle");

    By courseLink = By.id("courseLink");
    By feeLink = By.id("feeLink");
    By feedbackLink = By.id("feedbackLink");
    By logoutLink = By.id("logoutLink");

    By courseCardBtn = By.id("courseCardBtn");
    By feeCardBtn = By.id("feeCardBtn");
    By feedbackCardBtn = By.id("feedbackCardBtn");

    @BeforeMethod
    public void setup() {

        driver = new ChromeDriver();
        driver.manage().window().maximize();

        String path = new File(
                "src/test/student-portal-testing-project/dashboard.html")
                .getAbsolutePath();

        driver.get("file:///" + path.replace('\\', '/'));
    }

    @Test
    public void verifyDashboardTitle() {

        Assert.assertEquals(
                driver.findElement(pageTitle).getText(),
                "Welcome to Student Dashboard");
    }

    @Test
    public void verifyAppName() {

        Assert.assertEquals(
                driver.findElement(appName).getText(),
                "Student Portal");
    }

    @Test
    public void verifyCourseNavbarLink() {

        String href =
                driver.findElement(courseLink)
                      .getAttribute("href");

        Assert.assertTrue(
                href.contains("course-enquiry.html"));
    }

    @Test
    public void verifyFeeNavbarLink() {

        String href =
                driver.findElement(feeLink)
                      .getAttribute("href");

        Assert.assertTrue(
                href.contains("fee-calculator.html"));
    }

    @Test
    public void verifyFeedbackNavbarLink() {

        String href =
                driver.findElement(feedbackLink)
                      .getAttribute("href");

        Assert.assertTrue(
                href.contains("feedback.html"));
    }

    @Test
    public void verifyLogoutNavbarLink() {

        String href =
                driver.findElement(logoutLink)
                      .getAttribute("href");

        Assert.assertTrue(
                href.contains("index.html"));
    }

    @Test
    public void verifyCourseCardButton() {

        String href =
                driver.findElement(courseCardBtn)
                      .getAttribute("href");

        Assert.assertTrue(
                href.contains("course-enquiry.html"));
    }

    @Test
    public void verifyFeeCardButton() {

        String href =
                driver.findElement(feeCardBtn)
                      .getAttribute("href");

        Assert.assertTrue(
                href.contains("fee-calculator.html"));
    }

    @Test
    public void verifyFeedbackCardButton() {

        String href =
                driver.findElement(feedbackCardBtn)
                      .getAttribute("href");

        Assert.assertTrue(
                href.contains("feedback.html"));
    }

    @AfterMethod
    public void tearDown() {

        if (driver != null) {
            driver.quit();
        }
    }
}