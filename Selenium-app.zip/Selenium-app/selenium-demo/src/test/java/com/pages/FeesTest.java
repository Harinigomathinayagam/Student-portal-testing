package com.pages;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class FeesTest {

    WebDriver driver;

    By pageTitle = By.id("pageTitle");
    By courseDropdown = By.id("course");
    By discountBox = By.id("discount");
    By calculateButton = By.id("calculateBtn");
    By messageBox = By.id("message");
    By resultBox = By.id("result");

    @BeforeMethod
    public void setup() {

        driver = new ChromeDriver();
        driver.manage().window().maximize();

        String path = new File(
                "src/test/student-portal-testing-project/fee-calculator.html")
                .getAbsolutePath();

        driver.get("file:///" + path.replace('\\', '/'));
    }

    public String getMessage() {

        WebDriverWait wait =
                new WebDriverWait(driver, Duration.ofSeconds(5));

        return wait.until(d -> {
            String messageText = d.findElement(messageBox).getText().trim();
            if (!messageText.isEmpty()) {
                return messageText;
            }
            String resultText = d.findElement(resultBox).getText().trim();
            if (!resultText.isEmpty()) {
                return resultText;
            }
            return null;
        });
    }

    private void selectCourse(String courseText) {
        Select select = new Select(driver.findElement(courseDropdown));
        select.selectByVisibleText(courseText);
    }

    @Test
    public void verifyPageTitle() {

        Assert.assertEquals(
                driver.findElement(pageTitle).getText(),
                "Course Fee Calculator");
    }

    @Test
    public void verifyDiscountPlaceholder() {

        String placeholder =
                driver.findElement(discountBox)
                        .getAttribute("placeholder");

        Assert.assertEquals(
                placeholder,
                "Enter discount percentage");
    }

    @Test
    public void verifyCourseRequired() {

        driver.findElement(calculateButton).click();

        Assert.assertEquals(
                getMessage(),
                "Course is required");
    }

    @Test
    public void verifyDiscountRequired() {

        selectCourse("Java Full Stack - Rs.30000");

        driver.findElement(calculateButton)
                .click();

        Assert.assertEquals(
                getMessage(),
                "Discount is required");
    }

    @Test
    public void verifyDiscountMustBeNumber() {

        selectCourse("Java Full Stack - Rs.30000");

        driver.findElement(discountBox)
                .sendKeys("abc");

        driver.findElement(calculateButton)
                .click();

        Assert.assertEquals(
                getMessage(),
                "Discount should be a number");
    }

    @Test
    public void verifyDiscountBelowZero() {

        selectCourse("Java Full Stack - Rs.30000");

        driver.findElement(discountBox)
                .sendKeys("-5");

        driver.findElement(calculateButton)
                .click();

        Assert.assertEquals(
                getMessage(),
                "Discount should be between 0 and 50");
    }

    @Test
    public void verifyDiscountAboveFifty() {

        selectCourse("Java Full Stack - Rs.30000");

        driver.findElement(discountBox)
                .sendKeys("60");

        driver.findElement(calculateButton)
                .click();

        Assert.assertEquals(
                getMessage(),
                "Discount should be between 0 and 50");
    }

    @Test
    public void verifyJavaFullStackFeeCalculation() {

        selectCourse("Java Full Stack - Rs.30000");

        driver.findElement(discountBox)
                .sendKeys("10");

        driver.findElement(calculateButton)
                .click();

        Assert.assertEquals(
                getMessage(),
                "Final Fee: Rs.27000");
    }

    @Test
    public void verifySoftwareTestingFeeCalculation() {

        selectCourse("Software Testing - Rs.25000");

        driver.findElement(discountBox)
                .sendKeys("20");

        driver.findElement(calculateButton)
                .click();

        Assert.assertEquals(
                getMessage(),
                "Final Fee: Rs.20000");
    }

    @AfterMethod
    public void tearDown() {

        if (driver != null) {
            driver.quit();
        }
    }
}